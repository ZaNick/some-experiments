import { TestBed } from '@angular/core/testing';

import { KbmFormService } from './kbm-form.service';

describe('KbmFormService', () => {
  let service: KbmFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KbmFormService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
