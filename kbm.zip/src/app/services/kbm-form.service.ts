import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormSteps } from '../components/form-page/form-page.component';

@Injectable({
	providedIn: 'root'
})
export class KbmFormService {
	kbmForm: FormGroup;

	constructor(
		fb: FormBuilder
	) {
		this.kbmForm = fb.group({
			policy: [null, Validators.required],
			otherPolicy: fb.group({
				series: [null, Validators.required],
				number: [null, Validators.required]
			}),
			driver: [null, Validators.required]
		});
	}


	isStepValid(step: FormSteps) {
		switch (step) {
			case FormSteps.policy:
				return this.kbmForm.get('policy')?.valid;
			case FormSteps.driver:
				return this.kbmForm.get('driver')?.valid;
		}
		return true;
	}
}
