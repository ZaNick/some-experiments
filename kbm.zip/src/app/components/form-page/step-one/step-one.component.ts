import { Component, Input, OnInit } from '@angular/core';
import { KbmFormService } from 'src/app/services/kbm-form.service';

interface PolicyShortInfo {
	car: {
		mark: string;
		model: string;
		number: string;
	};
	number: string;
	activeTill: string;
}

@Component({
	selector: 'app-step-one',
	templateUrl: './step-one.component.html',
	styleUrls: ['./step-one.component.scss']
})
export class StepOneComponent implements OnInit {

	@Input() isEdit = false;

	polices: PolicyShortInfo[] = [
		{
			car: {
				mark: 'Kia',
				model: 'Spectra',
				number: 'Е322КХ32'
			},
			number: 'XXX0139681001',
			activeTill: '31.06.2019'
		},
		{
			car: {
				mark: 'Kia',
				model: 'Spectra',
				number: 'Е322КХ32'
			},
			number: 'XXX0139681001',
			activeTill: '31.06.2019'
		},
	];

	seriesList = ['XXX', 'YYY'];

	constructor(
		private kbmFormService: KbmFormService,
	) { }

	ngOnInit(): void {
	}

	get kbmForm() {
		return this.kbmFormService.kbmForm;
	}

}
