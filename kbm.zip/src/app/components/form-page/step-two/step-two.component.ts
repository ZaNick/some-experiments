import { Component, Input, OnInit } from '@angular/core';
import { KbmFormService } from 'src/app/services/kbm-form.service';

@Component({
	selector: 'app-step-two',
	templateUrl: './step-two.component.html',
	styleUrls: ['./step-two.component.scss']
})
export class StepTwoComponent implements OnInit {

	@Input() isEdit = false;
	driversList = [
		{
			name: 'Константинопольский Константин Константинович',
			birthDay: '11.02.1992',
			driverLicence: '5085 ВХ12345',
			kbm: '0.7'
		},
		{
			name: 'Римский Марк Аврелиевич',
			birthDay: '11.02.1992',
			driverLicence: '5085 ВХ12345',
			kbm: '0.8'
		},
	];

	constructor(
		private kbmFormService: KbmFormService,
	) { }

	ngOnInit(): void {
	}

	get kbmForm() {
		return this.kbmFormService.kbmForm;
	}

}
