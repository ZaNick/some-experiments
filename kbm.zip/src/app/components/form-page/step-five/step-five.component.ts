import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
	selector: 'app-step-five',
	templateUrl: './step-five.component.html',
	styleUrls: ['./step-five.component.scss']
})
export class StepFiveComponent implements OnInit {

	@Input() isEdit = false;
	@Output() reset = new EventEmitter<void>();

	constructor() { }

	ngOnInit(): void {
	}

	onResetClick() {
		this.reset.emit();
	}
}
