import { Component, Input, OnInit } from '@angular/core';

@Component({
	selector: 'app-step-four',
	templateUrl: './step-four.component.html',
	styleUrls: ['./step-four.component.scss']
})
export class StepFourComponent implements OnInit {

	@Input() isEdit = false;

	constructor() { }

	ngOnInit(): void {
	}

}
