import { Component, Input, OnInit } from '@angular/core';
import { collapse } from 'src/app/animations';
import { KbmFormService } from 'src/app/services/kbm-form.service';

@Component({
	selector: 'app-step-three',
	templateUrl: './step-three.component.html',
	styleUrls: ['./step-three.component.scss'],
	animations: [collapse]
})
export class StepThreeComponent implements OnInit {

	@Input() isEdit = false;
	isExpanded = false;

	constructor(
		private kbmFormService: KbmFormService,
	) { }

	ngOnInit(): void {
	}

	get kbmForm() {
		return this.kbmFormService.kbmForm;
	}

	toggleExpand() {
		this.isExpanded = !this.isExpanded;
	}
}
