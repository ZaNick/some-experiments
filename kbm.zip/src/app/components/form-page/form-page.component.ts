import { Component, OnInit } from '@angular/core';
import { KbmFormService } from 'src/app/services/kbm-form.service';

export enum FormSteps {
	policy = 1,
	driver = 2,
	clarification = 3,
	request = 4,
	result = 5,
}

@Component({
	selector: 'app-form-page',
	templateUrl: './form-page.component.html',
	styleUrls: ['./form-page.component.scss']
})
export class FormPageComponent implements OnInit {

	currentStep: FormSteps = FormSteps.policy;
	formSteps = FormSteps;

	constructor(
		public kbmFormService: KbmFormService
	) { }

	ngOnInit(): void {
	}

	get currentStepTitle() {
		switch (this.currentStep) {
			case FormSteps.policy: return 'Выбор полиса';
			case FormSteps.clarification:
			case FormSteps.driver: return 'Выбор водителя';
			case FormSteps.request: return 'Формирование запроса';
			case FormSteps.result: return 'Результаты проверки';

			default: return '';
		}
	}

	get currentStepDescription() {
		switch (this.currentStep) {
			case FormSteps.policy: return 'Выберите один из предложенных полисов ОСАГО Если полиса нет в списке — выберите пункт «Другой полис ОСАГО»';
			case FormSteps.driver: return 'Выберите допущенного к управлению водителя по которому вы хотели бы проверить коэффициента бонус-малус';
			case FormSteps.clarification: return 'Уточнение данных по водителю';
			case FormSteps.request: return 'Проверка данных и отправка запроса';

			default: return '';
		}
	}

	get currentStepButton() {
		switch (this.currentStep) {
			case FormSteps.request: return 'Сформировать заявления в КБМ+';

			default: return 'Продолжить';
		}
	}

	goToNextStep() {
		this.currentStep++;
	}

	onResetForm() {
		this.currentStep = FormSteps.policy;
		this.kbmFormService.kbmForm.reset();
	}
}
