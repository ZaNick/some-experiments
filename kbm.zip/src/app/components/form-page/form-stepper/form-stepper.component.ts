import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormSteps } from '../form-page.component';

@Component({
	selector: 'app-form-stepper',
	templateUrl: './form-stepper.component.html',
	styleUrls: ['./form-stepper.component.scss']
})
export class FormStepperComponent implements OnInit {

	@ViewChild('stepper') stepperRef!: ElementRef<HTMLDivElement>
	@Output() currentStepChange = new EventEmitter<FormSteps>();
	@Input() currentStep!: FormSteps;
	mutationObserver!: MutationObserver;
	progressWidth = 0;
	formSteps = FormSteps;

	constructor() { }

	ngOnInit(): void {
	}

	ngOnDestroy() {
		this.mutationObserver.disconnect();
	}

	ngAfterViewInit() {
		setTimeout(() => { // ExpressionChangedAfterItHasBeenCheckedError :(
			this.updateProgressPosition();
		});

		this.mutationObserver = new MutationObserver(() => {
			this.updateProgressPosition();
		});

		this.mutationObserver.observe(this.stepperRef.nativeElement, {
			attributes: true,
			attributeFilter: ['class'],
			childList: true,
			subtree: true,
		});
	}

	updateProgressPosition() {
		const activeElements = this.stepperRef.nativeElement.querySelectorAll('.active');
		if (activeElements.length) {
			const latestActiveEl = activeElements.item(activeElements.length - 1) as HTMLDivElement;
			console.log('latestActiveEl :>> ', { latestActiveEl });
			this.progressWidth = latestActiveEl.offsetLeft + latestActiveEl.offsetWidth;
		}
	}

	onStepClick(index: FormSteps) {
		this.currentStep = index;
		this.currentStepChange.emit(index);
	}
}
