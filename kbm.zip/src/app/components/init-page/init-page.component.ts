import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
	selector: 'app-init-page',
	templateUrl: './init-page.component.html',
	styleUrls: ['./init-page.component.scss']
})
export class InitPageComponent implements OnInit {

	@Output() initFormMode = new EventEmitter<void>();

	constructor() { }

	ngOnInit(): void {
	}

}
