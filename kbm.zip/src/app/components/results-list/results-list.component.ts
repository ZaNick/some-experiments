import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-results-list',
	templateUrl: './results-list.component.html',
	styleUrls: ['./results-list.component.scss']
})
export class ResultsListComponent implements OnInit {

	results = [
		{
			number: 123456,
			date: '12.23.4567',
			driver: {
				name: 'Константинопольский Константин Константинович',
				birthDay: '11.02.1992',
				driverLicence: '5085 ВХ12345',
				kbm: '0.7'
			},
			statusId: 0,
			statusName: 'Обработка РСА',
		},
		{
			number: '...',
			date: '12.23.4567',
			driver: {
				name: 'Константинопольский Константин Константинович',
				birthDay: '11.02.1992',
				driverLicence: '5085 ВХ12345',
				kbm: '0.7'
			},
			statusId: 0,
			statusName: 'Принято СК',
		},
		{
			number: 123456,
			date: '12.23.4567',
			driver: {
				name: 'Константинопольский Константин Константинович',
				birthDay: '11.02.1992',
				driverLicence: '5085 ВХ12345',
				kbm: '0.7'
			},
			statusId: 1,
			statusName: 'Завершено',
		},
	];

	constructor() { }

	ngOnInit(): void {
	}

}
