import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { collapse } from 'src/app/animations';

@Component({
	selector: 'app-faq',
	templateUrl: './faq.component.html',
	styleUrls: ['./faq.component.scss'],
	animations: [collapse]
})
export class FaqComponent implements OnInit {

	questions: {
		q: string;
		a: string;
		expanded?: boolean;
	}[] = [
		{
			q: 'Что такое КБМ и для чего он нужен?',
			a: 'КБМ (коэффициент бонус-малус, скидка за безаварийную езду) - один из показателей, влияющих на стоимость полиса ОСАГО. В зависимости от наличия/отсутствия страховых выплат коэффициент может быть повышающим или понижающим',
		},
		{
			q: 'Я поменял права, при этом мой КБМ стал равен 1. Что делать?',
			a: 'lorem',
		},
		{
			q: 'Что делать если я не согласен с КБМ?',
			a: 'lorem',
		},
		{
			q: 'Какие документы я должен предоставить для проверки КБМ?',
			a: 'lorem',
		},
		{
			q: 'В какой срок рассматривается заявление?',
			a: 'lorem',
		},
	];
	constructor() { }

	ngOnInit(): void {
	}

}
