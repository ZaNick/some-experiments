import { LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { InitPageComponent } from './components/init-page/init-page.component';
import { FaqComponent } from './components/faq/faq.component';
import { FormPageComponent } from './components/form-page/form-page.component';
import { FormStepperComponent } from './components/form-page/form-stepper/form-stepper.component';
import { StepOneComponent } from './components/form-page/step-one/step-one.component';
import { StepTwoComponent } from './components/form-page/step-two/step-two.component';
import { StepThreeComponent } from './components/form-page/step-three/step-three.component';
import { StepFourComponent } from './components/form-page/step-four/step-four.component';
import { StepFiveComponent } from './components/form-page/step-five/step-five.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from './material/material.module';
import localeRu from '@angular/common/locales/ru';
import localeRuExtra from '@angular/common/locales/extra/ru';
import { registerLocaleData } from '@angular/common';
import { InitialsPipe } from './pipes/initials.pipe';
import { ResultsListComponent } from './components/results-list/results-list.component';
registerLocaleData(localeRu, 'ru', localeRuExtra);

@NgModule({
	declarations: [
		AppComponent,
		InitPageComponent,
		FaqComponent,
		FormPageComponent,
		FormStepperComponent,
		StepOneComponent,
		StepTwoComponent,
		StepThreeComponent,
		StepFourComponent,
		StepFiveComponent,
  InitialsPipe,
  ResultsListComponent
	],
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		FormsModule,
		ReactiveFormsModule,
		MaterialModule,
	],
	providers: [
		{ provide: LOCALE_ID, useValue: 'ru' },
	],
	bootstrap: [AppComponent]
})
export class AppModule { }
