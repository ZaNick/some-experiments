import { animate, state, style, transition, trigger } from '@angular/animations';

export const collapse = trigger('collapse', [
	state('void', style({
		height: 0,
		overflow: 'hidden'
	})),
	state('*', style({ overflow: 'hidden', height: '*' })),
	transition('void <=> *', animate('0.24s ease-in-out'))
]);
