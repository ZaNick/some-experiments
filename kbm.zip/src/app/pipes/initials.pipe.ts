import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
	name: 'initials'
})
export class InitialsPipe implements PipeTransform {

	transform(item: string | any): string {
		if (!item) {
			return '';
		}
		let LastName;
		let FirstName;
		let MiddleName;
		[LastName, FirstName, MiddleName] = item.split(' ');
		FirstName = FirstName ? `${FirstName.substring(0, 1)}.` : null;
		MiddleName = MiddleName ? `${MiddleName.substring(0, 1)}.` : null;

		return [LastName, FirstName, MiddleName]
			.filter(t => !!t)
			.join('\xa0');
	}
}
